var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/(frontend)/api/auth/callback/route.js")
R.c("server/chunks/[externals]__0xp-w031ecr12._.js")
R.c("server/chunks/_0u27ex1rt2zs5._.js")
R.c("server/chunks/[root-of-the-server]__1jt8hi2th_m4_._.js")
R.c("server/chunks/[root-of-the-server]__0pug-v-5iw_m8._.js")
R.c("server/chunks/1oeh_server_app_(frontend)_api_auth_callback_route_actions_1z_1t2jp64os_.js")
R.m(17587)
module.exports=R.m(17587).exports
