:HL["/_next/static/chunks/0c56q2274v0kd.css","style"]
:HL["/_next/static/chunks/39qnxfpmtqg5z.css","style"]
3:[["children",{"s":"__PAGE__","h":160}]]
2:[["children",{"s":"updates","h":96,"c":"$Q3"}]]
1:[["children",{"s":"(frontend)","h":112,"c":"$Q2"}]]
0:{"b":"LpCojFSmRC8atdPaQuj_6","t":{"t":{"s":"","h":80,"c":"$Q1"}}}
